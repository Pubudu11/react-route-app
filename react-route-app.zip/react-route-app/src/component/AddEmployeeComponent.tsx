import React from "react";

const AddEmployeeComponent: React.FC = () => {
  return <div>Add or Update Employee Details Here</div>;
};

export default AddEmployeeComponent;
