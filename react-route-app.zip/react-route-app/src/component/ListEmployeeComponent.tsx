import React from "react";

const ListEmployeeComponent: React.FC = () => {
  return <div>Welcome to the Employee List!</div>;
};

export default ListEmployeeComponent;
